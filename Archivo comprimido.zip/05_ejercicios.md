# Ejercicios #

## Lista de peliculas ##

- Crear un archivo llamado capturar\_peliculas.py
- Crear una variable llamada titulo\_log que contenga una cadena con el titulo de la aplicación 
- Crear una variable llamado creado\_por que contenga una cadena con el nombre del autor
- Crear una variable llamada version que contenta un numero real con la version 
- Crear una variable cabecera que contenta las cadenas titulo\_log en formato title, la cadena version y la cadena creado\_por.
- Imprimer la variable cabecera
- Pedir el numero de elementos a capturar, solo aceptar enteros.
- Crear un diccionario con las siguientes llaves: titulo, ano, actores, genero, fecha\_de\_captura.
- Almacenar estos diccionarios en una lista llamada peliculas.
- Crear un archivo CSV donde cada elemento de la lista.
- Crear otro archivo que lea el CSV generado y muestre solo las peliculas que se publicaron despues del año 2000.
- Probar filtrando datos con diferentes criterios.
- Crear una lista con diccionarios con los resultados y añadirle mas elementos.
- Practicar añadiendo mas campos al diccionario peliculas.
